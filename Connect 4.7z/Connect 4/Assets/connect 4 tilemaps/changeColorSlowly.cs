﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changeColorSlowly : MonoBehaviour {

	//Color tile1Color = new Color32(242, 27, 63, 255);
	//Color tile2Color = new Color32(238, 232, 44, 255);
	//SpriteRenderer mySpriteRendererTC;

	// Use this for initialization
	void Start () {
		//mySpriteRendererTC = this.GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
		//mySpriteRendererTC.color = Color.Lerp(tile1Color, tile2Color, Mathf.PingPong(Time.time, 1));
	}
}
